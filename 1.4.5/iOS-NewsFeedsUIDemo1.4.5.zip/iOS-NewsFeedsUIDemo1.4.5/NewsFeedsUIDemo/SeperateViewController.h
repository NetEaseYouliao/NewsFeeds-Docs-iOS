//
//  SeperateViewController.h
//  NewsFeedsUIDemo
//
//  Created by shoulei ma on 2017/10/13.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NewsFeedsUISDK/NewsFeedsUISDK.h>

@interface SeperateViewController : UIViewController

@end
