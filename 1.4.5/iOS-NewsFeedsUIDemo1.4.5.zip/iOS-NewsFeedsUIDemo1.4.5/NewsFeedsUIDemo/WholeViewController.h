//
//  ViewController.h
//  NewsFeedsUIDemo
//
//  Created by shoulei ma on 2017/10/11.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WholeViewController : UIViewController


@end

